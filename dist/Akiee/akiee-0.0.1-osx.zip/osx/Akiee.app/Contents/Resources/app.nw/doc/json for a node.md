{
"key":"orgNode_33.##",
"level":2,
"headline":"As a user I want to change the state of a task with a simple action, that I can easyly check my task without switching to the editor and breaking my flow.",
"body":"",
"tag":null,
"tags":{},
"todo":"DOING",
"priority":null,
"scheduled":null,
"deadline":null,
"properties":{},
"drawer":{},
"rank":null
}